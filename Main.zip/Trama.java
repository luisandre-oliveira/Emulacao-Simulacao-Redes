package com.emulacao.chat;

public class Trama {

    private byte address, control, dados, crc, flag1, flag2;
    private byte[] data = new byte[11];

    public Trama(short address, int control, int dados, int crc, int flag1, int flag2)
    {
        this.address = (byte)address;
        this.control = (byte)control;
        this.dados = (byte)dados;
        this.crc = (byte)crc;
        this.flag1 = (byte)flag1;
        this.flag2 = (byte)flag2;
        this.control = (byte)(this.control & 0xFF);
        if(control == 'u');
        if(control == 'i');
        if(control == 's');
        fazerTrama();
    }

    public byte[] fazerTrama()
    {
        data[0] = this.flag1;
        data[2] = this.address;
        data[8] = this.control;
        data[9] = this.dados;
        data[8] = this.crc;
        data[10] = this.flag2;
        return this.data;
    }
}



package com.emulacao.chat;
//Imports Serial
import com.fazecast.jSerialComm.SerialPort;
import com.fazecast.jSerialComm.SerialPortDataListener;
import com.fazecast.jSerialComm.SerialPortEvent;
//Imports JavaFX (GUI)
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextArea;
import javafx.stage.FileChooser;
import org.jetbrains.annotations.NotNull;
//Imports Manipulação de ficheiros
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;


public class Controller {

    SerialPort porta;
    String dataBuffer = "";
    final String newLine = "\n";
    String result;
    ArrayList<Byte> textoConvertido = new ArrayList<>();
    boolean abcde;

    @FXML
    public TextArea chat;
    public TextArea submit;
    public ComboBox Xporta;
    public ComboBox Xbaud;
    public ComboBox Xstop;
    public ComboBox Xdata;
    public ComboBox Xparity;
    public ProgressBar progresso;
    public Button butone;
    public Button bEnviar;
    public Button refresh;

    @FXML
    public void initialize() {
        abcde = false;
        bEnviar.setDisable(true);
        //baud rate
        Xbaud.getItems().removeAll(Xbaud.getItems());
        Xbaud.getItems().addAll(2400,9600,28800,56000,115200,256000);
        Xbaud.getSelectionModel().select(1);
        //porta
        scan();
        progresso.setProgress(1F);
        progresso.setStyle("-fx-accent: red");
        //data bits
        Xdata.getItems().removeAll(Xdata.getItems());
        Xdata.getItems().addAll(5,6,7,8);
        Xdata.getSelectionModel().select(3);
        //stop bits
        Xstop.getItems().removeAll(Xstop.getItems());
        Xstop.getItems().add(0,1);
        Xstop.getItems().add(1,1.5);
        Xstop.getItems().add(2,2);
        Xstop.getSelectionModel().select(0);
        //parity
        Xparity.getItems().removeAll(Xparity.getItems());
        Xparity.getItems().addAll("Nenhuma","Par","Ímpar","Marcação","Espacial");
        Xparity.getSelectionModel().select(0);
    }

    @FXML
    public void enviar(){
        if (submit.getText() != null) {
            Serial_EventBasedReading(porta);
            chat.appendText("PC1: " + submit.getText());
            for(int i = 0; i < submit.getText().length(); i++)
            {
                textoConvertido.add((byte)(int)(submit.getText().charAt(i)));
            }
            byte[] textConverts = new byte[textoConvertido.size()];
            int u = 0;
            for(Byte b : textoConvertido)
            {
                textConverts[u] = b;
                u++;
            }
            porta.writeBytes(textConverts, textoConvertido.size());
            chat.appendText("\n");
            submit.setText(null);
            textoConvertido.clear();
        }
    }

    public void anexar(){
        if(abcde == false){chat.appendText("Ligue uma porta primeiro\n"); return;}
         FileDialog fd = new FileDialog(new Frame());
         fd.setFile("*.txt");
         fd.setTitle("Escolha o ficheiro a enviar...");
         fd.setMultipleMode(false);
         fd.setVisible(true);
         File[] f = fd.getFiles();
         if(f.length > 0){
         //System.out.println(fd.getFiles()[0].getAbsolutePath());
         }
         //Caso nenhum ficheiro seja escolhido
         try{enviarTXT(fd.getFiles()[0].getAbsolutePath());}catch (Exception e){chat.appendText("\nErro ao escolher/enviar o ficheiro");}
    }

    public void anexarI(){
        if(abcde == false){chat.appendText("Ligue uma porta primeiro\n");return;}
        FileDialog fd = new FileDialog(new Frame());
        fd.setFile("*.txt,*.jpg,*.jpeg,*.png,*.ico,*.svg,*.JPG,*.JPEG,*.PNG,*.ICO,*.SVG");
        fd.setTitle("Escolha o ficheiro a enviar...");
        fd.setMultipleMode(false);
        fd.setVisible(true);
        File[] f = fd.getFiles();
        /**if(f.length > 0){
            System.out.println(fd.getFiles()[0].getAbsolutePath());
        }**/
        //Caso nenhum ficheiro seja escolhido
        try{enviarIMG(fd.getFiles()[0].getAbsolutePath());}catch (Exception e){chat.appendText("\nErro ao escolher o ficheiro");}
    }

    public void enviarTXT(String filePath) {
        if(filePath == "" || filePath == null){chat.appendText("Não foi possível ler o ficheiro. Tente novamente."); return;}
        File txt = new File(filePath);
        if (txt == null) {
            chat.appendText("Não possível enviar o texto");
        }
        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader(filePath));
            String line = reader.readLine();
            while (line != null) {
                for (int y = 0; y < line.length(); y++) {
                    byte[] bytes = new byte[1];
                    bytes[0] = (byte) (int) (line.charAt(y));
                    porta.writeBytes(bytes, bytes.length);
                    //LIMPAR ARRAY
                }
                porta.writeBytes(newLine.getBytes(),newLine.length());
                //System.out.println(line);
                line = reader.readLine();
            }
            reader.close();
            chat.appendText("Ficheiro enviado com sucesso!\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void enviarIMG(String filePath) throws IOException {
        BufferedImage imagem = ImageIO.read(new File(filePath));
        ByteArrayOutputStream imagemArray = new ByteArrayOutputStream();
        ImageIO.write(imagem, "jpg", imagemArray);
        byte[] bytes = imagemArray.toByteArray();
        porta.writeBytes(bytes, bytes.length);

        BufferedImage img = ImageIO.read(new ByteArrayInputStream(bytes));
        FileChooser ol = new FileChooser();
        ol.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("All Files", "*.jpg,*.jpeg,*.png,*.ico,*.svg,*.JPG,*.JPEG,*.PNG,*.ICO,*.SVG"));
        File recebido = ol.showSaveDialog(Main.scene.getWindow());
        Path file = Paths.get("temp.txt");
        try {
            PrintWriter writer;
            writer = new PrintWriter(recebido);
            writer.println();
            writer.close();
            /*if (file != null) {
                saveTextToFile(sampleText, file);
            }*/
        } catch (IOException ex) {
            chat.appendText("NAO RESULTOU");
        }
        chat.appendText(recebido.getAbsolutePath());
    }

    public void scan()
    {
        Xporta.getItems().removeAll(Xporta.getItems());
        SerialPort[] ports = SerialPort.getCommPorts();
        for(SerialPort port : ports)
        {
            Xporta.getItems().add(port.getSystemPortName());
        }
        Xporta.getSelectionModel().select("Escolher");
    }

    public void Serial_EventBasedReading(@NotNull SerialPort porta) {
        porta.addDataListener(new SerialPortDataListener() {
            @Override
            public int getListeningEvents() {
                return porta.LISTENING_EVENT_DATA_AVAILABLE | porta.LISTENING_EVENT_DATA_RECEIVED;
            }
            @Override
            public void serialEvent(SerialPortEvent event) {
                byte[] newData = event.getReceivedData();
                for (int i = 0; i < newData.length; i++) {
                    dataBuffer += (char)(int)(newData[i] & 0xFF);
                }
                chat.appendText("PC2: " + dataBuffer);
                chat.appendText("\n");
                porta.flushIOBuffers();
                result = "";
                dataBuffer = "";
            }
        });
    }

    public short connect() {
        if(abcde == true)
        {
            porta.closePort();
            abcde = false;
            butone.setText("Ligar");
            Xporta.setDisable(false);
            Xbaud.setDisable(false);
            Xstop.setDisable(false);
            Xdata.setDisable(false);
            Xparity.setDisable(false);
            progresso.setStyle("-fx-accent: red");
            bEnviar.setDisable(true);
            refresh.setDisable(false);
            return 0;
        }
        progresso.setStyle("-fx-accent: yellow");
        try{
            int l = Xporta.getSelectionModel().getSelectedIndex();
            SerialPort[] p = SerialPort.getCommPorts();
            porta = p[l];
            setParam(Xbaud.getSelectionModel().getSelectedIndex(),
                    Xdata.getSelectionModel().getSelectedIndex(),
                    Xstop.getSelectionModel().getSelectedIndex(),
                    Xparity.getSelectionModel().getSelectedIndex());
            porta.setComPortTimeouts(SerialPort.TIMEOUT_READ_BLOCKING, 0, 0);
            Serial_EventBasedReading(porta);
            porta.openPort();
            butone.setText("Desligar");
            Xporta.setDisable(true);
            Xbaud.setDisable(true);
            Xstop.setDisable(true);
            Xdata.setDisable(true);
            Xparity.setDisable(true);
            progresso.setStyle("-fx-accent: green");
            bEnviar.setDisable(false);
            refresh.setDisable(true);
            abcde = true;
            porta.setFlowControl(porta.FLOW_CONTROL_XONXOFF_IN_ENABLED);
            porta.setFlowControl(porta.FLOW_CONTROL_XONXOFF_OUT_ENABLED);
        }catch(Exception e){progresso.setStyle("-fx-accent: red");chat.appendText("Erro ao abrir a porta! Scan e tente novamente.\n");}
        return 0;
    }

    private void setParam(int baud, int data, int stop, int parity)
    {
        switch(baud)
        {
            case 0: porta.setBaudRate(2400); break;
            case 1: porta.setBaudRate(9600); break;
            case 2: porta.setBaudRate(28800); break;
            case 3: porta.setBaudRate(56000); break;
            case 4: porta.setBaudRate(115200); break;
            case 5: porta.setBaudRate(256000); break;
        }

        switch(data)
        {
            case 0: porta.setNumDataBits(5); break;
            case 1: porta.setNumDataBits(6); break;
            case 2: porta.setNumDataBits(7); break;
            case 3: porta.setNumDataBits(8); break;
        }

        switch(stop)
        {
            case 0: porta.setNumStopBits(1); break;
            case 1: porta.setNumStopBits(porta.ONE_POINT_FIVE_STOP_BITS); break;
            case 2: porta.setNumStopBits(porta.TWO_STOP_BITS); break;
        }
        switch(parity)
        {
            case 0: porta.setParity(porta.NO_PARITY); break;
            case 1: porta.setParity(porta.EVEN_PARITY); break;
            case 2: porta.setParity(porta.ODD_PARITY); break;
            case 3: porta.setParity(porta.MARK_PARITY); break;
            case 4: porta.setParity(porta.SPACE_PARITY); break;
        }
    }

    public void close(){System.exit(0);}
}

 /*public void enviarTXT() throws IOException {
        String filePath = "N:/IntelliJ/chat/src/main/resources/com/emulacao/chat/Ola.txt"; //13 bytes
        try{
            byte[] bytes = Files.readAllBytes(Paths.get(filePath));
            porta.writeBytes(bytes, bytes.length);
            System.out.println(bytes.length);
        }
        catch (IOException e){throw new IOException("INVALID FILE");}*/

